<?php

namespace App\Services;

use App\Models\SeedAccession;
use Illuminate\Support\Facades\DB;

/**
 * Service architecture: seluruh logika penyimpanan aksesi (induk + detail + pivot)
 * dibungkus transaksi database agar atomik.
 */
class SeedAccessionService
{
    public function create(array $data): SeedAccession
    {
        return DB::transaction(function () use ($data) {
            $accession = SeedAccession::create($this->mainFields($data));
            $accession->origin()->create($data['origin']);
            $accession->treatments()->sync($data['treatment_ids'] ?? []);

            return $accession;
        });
    }

    public function update(SeedAccession $accession, array $data): SeedAccession
    {
        return DB::transaction(function () use ($accession, $data) {
            $accession->update($this->mainFields($data));
            $accession->origin()->updateOrCreate(
                ['seed_accession_id' => $accession->id],
                $data['origin']
            );
            $accession->treatments()->sync($data['treatment_ids'] ?? []);

            return $accession;
        });
    }

    public function delete(SeedAccession $accession): void
    {
        DB::transaction(function () use ($accession) {
            $accession->treatments()->detach();
            $accession->origin()->delete();
            $accession->delete();
        });
    }

    private function mainFields(array $data): array
    {
        return collect($data)->only([
            'code', 'name', 'local_name', 'plant_group_id',
            'quantity_grams', 'status', 'notes',
        ])->all();
    }
}
