<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CollectionOrigin extends Model
{
    protected $fillable = [
        'seed_accession_id', 'province', 'regency', 'village',
        'altitude_masl', 'collector_name', 'collected_at',
    ];

    protected function casts(): array
    {
        return ['collected_at' => 'date'];
    }

    public function seedAccession(): BelongsTo
    {
        return $this->belongsTo(SeedAccession::class);
    }
}
