<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class SeedAccession extends Model
{
    public const STATUSES = ['aktif', 'karantina', 'habis'];

    protected $fillable = [
        'code', 'name', 'local_name', 'plant_group_id',
        'quantity_grams', 'status', 'notes',
    ];

    public function plantGroup(): BelongsTo
    {
        return $this->belongsTo(PlantGroup::class);
    }

    public function origin(): HasOne
    {
        return $this->hasOne(CollectionOrigin::class);
    }

    public function treatments(): BelongsToMany
    {
        return $this->belongsToMany(Treatment::class, 'accession_treatment')->withTimestamps();
    }

    /** Pencarian: kode, nama, nama lokal, atau kabupaten asal. */
    public function scopeSearch(Builder $query, ?string $keyword): Builder
    {
        return $query->when($keyword, function (Builder $q) use ($keyword) {
            $q->where(function (Builder $w) use ($keyword) {
                $w->where('code', 'like', "%{$keyword}%")
                  ->orWhere('name', 'like', "%{$keyword}%")
                  ->orWhere('local_name', 'like', "%{$keyword}%")
                  ->orWhereHas('origin', fn (Builder $o) => $o->where('regency', 'like', "%{$keyword}%"));
            });
        });
    }

    /** Filter: kelompok tanaman, status, dan perlakuan. */
    public function scopeFilter(Builder $query, array $filters): Builder
    {
        return $query
            ->when($filters['plant_group_id'] ?? null, fn (Builder $q, $v) => $q->where('plant_group_id', $v))
            ->when($filters['status'] ?? null, fn (Builder $q, $v) => $q->where('status', $v))
            ->when($filters['treatment_id'] ?? null, fn (Builder $q, $v) => $q->whereHas(
                'treatments', fn (Builder $t) => $t->where('treatments.id', $v)
            ));
    }
}
