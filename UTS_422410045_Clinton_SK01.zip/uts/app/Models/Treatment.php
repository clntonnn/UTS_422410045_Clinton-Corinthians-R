<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Treatment extends Model
{
    protected $fillable = ['name', 'temperature', 'description'];

    public function seedAccessions(): BelongsToMany
    {
        return $this->belongsToMany(SeedAccession::class, 'accession_treatment')->withTimestamps();
    }
}
