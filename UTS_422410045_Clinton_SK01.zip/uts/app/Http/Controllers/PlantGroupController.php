<?php

namespace App\Http\Controllers;

use App\Http\Requests\PlantGroupRequest;
use App\Models\PlantGroup;

class PlantGroupController extends Controller
{
    public function index()
    {
        return view('plant-groups.index', [
            'groups' => PlantGroup::withCount('seedAccessions')->orderBy('name')->paginate(10),
        ]);
    }

    public function create()
    {
        return view('plant-groups.create', ['group' => new PlantGroup()]);
    }

    public function store(PlantGroupRequest $request)
    {
        PlantGroup::create($request->validated());

        return redirect()->route('plant-groups.index')->with('success', 'Kelompok tanaman berhasil ditambahkan.');
    }

    public function edit(PlantGroup $plant_group)
    {
        return view('plant-groups.edit', ['group' => $plant_group]);
    }

    public function update(PlantGroupRequest $request, PlantGroup $plant_group)
    {
        $plant_group->update($request->validated());

        return redirect()->route('plant-groups.index')->with('success', 'Kelompok tanaman berhasil diperbarui.');
    }

    public function destroy(PlantGroup $plant_group)
    {
        if ($plant_group->seedAccessions()->exists()) {
            return back()->with('error', "Kelompok \"{$plant_group->name}\" masih dipakai oleh aksesi benih dan tidak bisa dihapus.");
        }

        $plant_group->delete();

        return redirect()->route('plant-groups.index')->with('success', 'Kelompok tanaman berhasil dihapus.');
    }
}
