<?php

namespace App\Http\Controllers;

use App\Http\Requests\TreatmentRequest;
use App\Models\Treatment;

class TreatmentController extends Controller
{
    public function index()
    {
        return view('treatments.index', [
            'treatments' => Treatment::withCount('seedAccessions')->orderBy('name')->paginate(10),
        ]);
    }

    public function create()
    {
        return view('treatments.create', ['treatment' => new Treatment()]);
    }

    public function store(TreatmentRequest $request)
    {
        Treatment::create($request->validated());

        return redirect()->route('treatments.index')->with('success', 'Perlakuan penyimpanan berhasil ditambahkan.');
    }

    public function edit(Treatment $treatment)
    {
        return view('treatments.edit', ['treatment' => $treatment]);
    }

    public function update(TreatmentRequest $request, Treatment $treatment)
    {
        $treatment->update($request->validated());

        return redirect()->route('treatments.index')->with('success', 'Perlakuan penyimpanan berhasil diperbarui.');
    }

    public function destroy(Treatment $treatment)
    {
        $treatment->delete(); // baris pivot ikut terhapus (cascadeOnDelete)

        return redirect()->route('treatments.index')->with('success', 'Perlakuan penyimpanan berhasil dihapus.');
    }
}
