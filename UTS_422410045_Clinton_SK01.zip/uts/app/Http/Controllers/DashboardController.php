<?php

namespace App\Http\Controllers;

use App\Models\PlantGroup;
use App\Models\SeedAccession;
use App\Models\Treatment;

class DashboardController extends Controller
{
    public function __invoke()
    {
        return view('dashboard', [
            'totalAccessions' => SeedAccession::count(),
            'totalGrams'      => SeedAccession::sum('quantity_grams'),
            'byStatus'        => SeedAccession::selectRaw('status, count(*) as total')->groupBy('status')->pluck('total', 'status'),
            'groups'          => PlantGroup::withCount('seedAccessions')->orderByDesc('seed_accessions_count')->get(),
            'totalTreatments' => Treatment::count(),
            'latest'          => SeedAccession::with('plantGroup')->latest()->take(5)->get(),
        ]);
    }
}
