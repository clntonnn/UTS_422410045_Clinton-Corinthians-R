<?php

namespace App\Http\Controllers;

use App\Http\Requests\SeedAccessionRequest;
use App\Models\PlantGroup;
use App\Models\SeedAccession;
use App\Models\Treatment;
use App\Services\SeedAccessionService;
use Illuminate\Http\Request;

class SeedAccessionController extends Controller
{
    public function __construct(private readonly SeedAccessionService $service)
    {
    }

    public function index(Request $request)
    {
        $accessions = SeedAccession::with(['plantGroup', 'origin', 'treatments'])
            ->search($request->query('q'))
            ->filter($request->only(['plant_group_id', 'status', 'treatment_id']))
            ->latest()
            ->paginate(10)
            ->withQueryString();

        return view('seed-accessions.index', [
            'accessions' => $accessions,
            'groups'     => PlantGroup::orderBy('name')->get(),
            'treatments' => Treatment::orderBy('name')->get(),
            'statuses'   => SeedAccession::STATUSES,
        ]);
    }

    public function create()
    {
        return view('seed-accessions.create', $this->formData(new SeedAccession()));
    }

    public function store(SeedAccessionRequest $request)
    {
        $accession = $this->service->create($request->validated());

        return redirect()->route('seed-accessions.show', $accession)
            ->with('success', "Aksesi {$accession->code} berhasil disimpan.");
    }

    public function show(SeedAccession $seed_accession)
    {
        $seed_accession->load(['plantGroup', 'origin', 'treatments']);

        return view('seed-accessions.show', ['accession' => $seed_accession]);
    }

    public function edit(SeedAccession $seed_accession)
    {
        $seed_accession->load(['origin', 'treatments']);

        return view('seed-accessions.edit', $this->formData($seed_accession));
    }

    public function update(SeedAccessionRequest $request, SeedAccession $seed_accession)
    {
        $this->service->update($seed_accession, $request->validated());

        return redirect()->route('seed-accessions.show', $seed_accession)
            ->with('success', "Aksesi {$seed_accession->code} berhasil diperbarui.");
    }

    public function destroy(SeedAccession $seed_accession)
    {
        $code = $seed_accession->code;
        $this->service->delete($seed_accession);

        return redirect()->route('seed-accessions.index')
            ->with('success', "Aksesi {$code} berhasil dihapus.");
    }

    private function formData(SeedAccession $accession): array
    {
        return [
            'accession'  => $accession,
            'groups'     => PlantGroup::orderBy('name')->get(),
            'treatments' => Treatment::orderBy('name')->get(),
            'statuses'   => SeedAccession::STATUSES,
        ];
    }
}
