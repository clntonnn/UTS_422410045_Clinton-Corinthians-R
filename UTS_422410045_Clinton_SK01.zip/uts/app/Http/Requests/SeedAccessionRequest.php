<?php

namespace App\Http\Requests;

use App\Models\SeedAccession;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class SeedAccessionRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        $id = $this->route('seed_accession')?->id;

        return [
            'code'             => ['required', 'string', 'max:30', 'regex:/^[A-Z0-9\-]+$/', Rule::unique('seed_accessions', 'code')->ignore($id)],
            'name'             => ['required', 'string', 'max:120'],
            'local_name'       => ['nullable', 'string', 'max:120'],
            'plant_group_id'   => ['required', 'exists:plant_groups,id'],
            'quantity_grams'   => ['required', 'integer', 'min:0', 'max:1000000'],
            'status'           => ['required', Rule::in(SeedAccession::STATUSES)],
            'notes'            => ['nullable', 'string', 'max:1000'],

            'origin.province'       => ['required', 'string', 'max:80'],
            'origin.regency'        => ['required', 'string', 'max:80'],
            'origin.village'        => ['nullable', 'string', 'max:80'],
            'origin.altitude_masl'  => ['nullable', 'integer', 'min:0', 'max:5000'],
            'origin.collector_name' => ['required', 'string', 'max:100'],
            'origin.collected_at'   => ['required', 'date', 'before_or_equal:today'],

            'treatment_ids'    => ['nullable', 'array'],
            'treatment_ids.*'  => ['integer', 'exists:treatments,id'],
        ];
    }

    public function attributes(): array
    {
        return [
            'code' => 'kode aksesi', 'name' => 'nama aksesi', 'local_name' => 'nama lokal',
            'plant_group_id' => 'kelompok tanaman', 'quantity_grams' => 'jumlah benih',
            'origin.province' => 'provinsi', 'origin.regency' => 'kabupaten/kota',
            'origin.collector_name' => 'nama pengumpul', 'origin.collected_at' => 'tanggal pengumpulan',
            'origin.altitude_masl' => 'ketinggian', 'treatment_ids' => 'perlakuan penyimpanan',
        ];
    }

    public function messages(): array
    {
        return [
            'code.regex' => 'Kode aksesi hanya boleh huruf kapital, angka, dan tanda hubung (contoh: BNH-0001).',
            'origin.collected_at.before_or_equal' => 'Tanggal pengumpulan tidak boleh di masa depan.',
        ];
    }
}
