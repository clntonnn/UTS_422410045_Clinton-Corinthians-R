<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PlantGroupController;
use App\Http\Controllers\SeedAccessionController;
use App\Http\Controllers\TreatmentController;
use Illuminate\Support\Facades\Route;

Route::get('/', DashboardController::class)->name('dashboard');

Route::resource('seed-accessions', SeedAccessionController::class);
Route::resource('plant-groups', PlantGroupController::class)->except('show');
Route::resource('treatments', TreatmentController::class)->except('show');
