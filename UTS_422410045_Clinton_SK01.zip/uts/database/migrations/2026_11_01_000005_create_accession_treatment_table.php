<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Pivot many-to-many: pilihan jamak perlakuan penyimpanan.
        Schema::create('accession_treatment', function (Blueprint $table) {
            $table->foreignId('seed_accession_id')->constrained()->cascadeOnDelete();
            $table->foreignId('treatment_id')->constrained()->cascadeOnDelete();
            $table->timestamps();
            $table->primary(['seed_accession_id', 'treatment_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('accession_treatment');
    }
};
