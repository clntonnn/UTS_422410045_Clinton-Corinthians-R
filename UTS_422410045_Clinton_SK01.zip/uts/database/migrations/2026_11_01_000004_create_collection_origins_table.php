<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Relasi one-to-one: satu aksesi hanya punya satu detail asal pengumpulan.
        Schema::create('collection_origins', function (Blueprint $table) {
            $table->id();
            $table->foreignId('seed_accession_id')->unique()->constrained()->cascadeOnDelete();
            $table->string('province', 80);
            $table->string('regency', 80);
            $table->string('village', 80)->nullable();
            $table->unsignedSmallInteger('altitude_masl')->nullable();
            $table->string('collector_name', 100);
            $table->date('collected_at');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('collection_origins');
    }
};
