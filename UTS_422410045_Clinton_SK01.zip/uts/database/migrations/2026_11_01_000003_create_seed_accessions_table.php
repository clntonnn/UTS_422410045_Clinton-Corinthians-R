<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('seed_accessions', function (Blueprint $table) {
            $table->id();
            $table->string('code', 30)->unique();
            $table->string('name', 120);
            $table->string('local_name', 120)->nullable();
            $table->foreignId('plant_group_id')->constrained()->restrictOnDelete();
            $table->unsignedInteger('quantity_grams')->default(0);
            $table->enum('status', ['aktif', 'karantina', 'habis'])->default('aktif');
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->index(['plant_group_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('seed_accessions');
    }
};
