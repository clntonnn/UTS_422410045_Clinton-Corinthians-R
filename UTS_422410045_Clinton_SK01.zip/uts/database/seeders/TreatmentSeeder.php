<?php

namespace Database\Seeders;

use App\Models\Treatment;
use Illuminate\Database\Seeder;

class TreatmentSeeder extends Seeder
{
    public function run(): void
    {
        $rows = [
            ['Pengeringan silika gel', '15-20 °C', 'Kadar air benih diturunkan ke 5-7% memakai silika gel.'],
            ['Penyimpanan dingin', '4 °C', 'Disimpan di ruang dingin untuk masa simpan jangka menengah.'],
            ['Penyimpanan beku', '-18 °C', 'Disimpan di freezer untuk koleksi dasar jangka panjang.'],
            ['Fumigasi', null, 'Pengendalian hama gudang sebelum benih dimasukkan ke wadah.'],
            ['Pengemasan foil kedap udara', null, 'Dikemas dalam aluminium foil yang direkat panas.'],
            ['Uji viabilitas berkala', null, 'Uji daya kecambah setiap 5 tahun.'],
        ];

        foreach ($rows as [$name, $temp, $desc]) {
            Treatment::updateOrCreate(['name' => $name], ['temperature' => $temp, 'description' => $desc]);
        }
    }
}
