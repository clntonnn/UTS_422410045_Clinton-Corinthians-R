<?php

namespace Database\Seeders;

use App\Models\PlantGroup;
use App\Models\SeedAccession;
use App\Models\Treatment;
use App\Services\SeedAccessionService;
use Illuminate\Database\Seeder;

class SeedAccessionSeeder extends Seeder
{
    public function run(SeedAccessionService $service): void
    {
        $g = PlantGroup::pluck('id', 'name');
        $t = Treatment::pluck('id', 'name');

        $rows = [
            ['BNH-0001', 'Padi Sigupai', 'Pare Gogo', 'Serealia', 1200, 'aktif',
                ['Jawa Barat', 'Garut', 'Cikajang', 1100, 'Ratna Wulandari', '2024-03-12'],
                ['Pengeringan silika gel', 'Penyimpanan beku', 'Pengemasan foil kedap udara']],
            ['BNH-0002', 'Jagung Pulut Harapan', 'Jagung Ketan', 'Serealia', 800, 'aktif',
                ['Nusa Tenggara Timur', 'Sikka', 'Nita', 350, 'Yohanes Lado', '2023-09-04'],
                ['Pengeringan silika gel', 'Penyimpanan dingin']],
            ['BNH-0003', 'Kacang Koro Benguk', 'Benguk', 'Kacang-kacangan', 450, 'karantina',
                ['Daerah Istimewa Yogyakarta', 'Gunungkidul', 'Playen', 200, 'Slamet Widodo', '2025-01-20'],
                ['Fumigasi', 'Penyimpanan dingin']],
            ['BNH-0004', 'Terong Ungu Ungaran', null, 'Sayuran', 150, 'aktif',
                ['Jawa Tengah', 'Semarang', 'Ungaran', 480, 'Dewi Anggraeni', '2024-11-02'],
                ['Pengeringan silika gel', 'Penyimpanan beku', 'Uji viabilitas berkala']],
            ['BNH-0005', 'Ubi Cilembu', 'Hui Boled', 'Umbi-umbian', 0, 'habis',
                ['Jawa Barat', 'Sumedang', 'Pamulihan', 800, 'Asep Saepudin', '2022-06-15'],
                []],
            ['BNH-0006', 'Wijen Putih Sumenep', 'Lengo', 'Rempah dan Obat', 320, 'aktif',
                ['Jawa Timur', 'Sumenep', 'Gapura', 15, 'Hasan Basri', '2025-05-08'],
                ['Pengeringan silika gel', 'Pengemasan foil kedap udara', 'Penyimpanan dingin']],
        ];

        foreach ($rows as [$code, $name, $local, $group, $qty, $status, $o, $treats]) {
            if (SeedAccession::where('code', $code)->exists()) {
                continue;
            }

            $service->create([
                'code' => $code, 'name' => $name, 'local_name' => $local,
                'plant_group_id' => $g[$group], 'quantity_grams' => $qty, 'status' => $status,
                'origin' => [
                    'province' => $o[0], 'regency' => $o[1], 'village' => $o[2],
                    'altitude_masl' => $o[3], 'collector_name' => $o[4], 'collected_at' => $o[5],
                ],
                'treatment_ids' => collect($treats)->map(fn ($n) => $t[$n])->all(),
            ]);
        }
    }
}
