<?php

namespace Database\Seeders;

use App\Models\PlantGroup;
use Illuminate\Database\Seeder;

class PlantGroupSeeder extends Seeder
{
    public function run(): void
    {
        $rows = [
            ['Serealia', 'Padi, jagung, sorgum, jali, dan serealia lokal lainnya.'],
            ['Kacang-kacangan', 'Kedelai, kacang tanah, kacang hijau, koro, dan kerabatnya.'],
            ['Sayuran', 'Terong, cabai, labu, kangkung, dan sayuran daun/buah lokal.'],
            ['Umbi-umbian', 'Ubi jalar, singkong, talas, uwi, dan gembili.'],
            ['Rempah dan Obat', 'Kemangi, kunyit, wijen, dan tanaman rempah-obat.'],
        ];

        foreach ($rows as [$name, $description]) {
            PlantGroup::updateOrCreate(['name' => $name], ['description' => $description]);
        }
    }
}
