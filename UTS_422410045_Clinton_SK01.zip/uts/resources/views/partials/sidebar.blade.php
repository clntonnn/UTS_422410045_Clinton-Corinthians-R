<aside class="sidebar">
    <a href="{{ route('dashboard') }}" class="brand">
        Bank Benih Pusaka
        <small>Koleksi benih varietas lokal</small>
    </a>

    <nav class="nav" aria-label="Menu utama">
        <a href="{{ route('dashboard') }}" @class(['active' => request()->routeIs('dashboard')])>Ringkasan</a>
        <a href="{{ route('seed-accessions.index') }}" @class(['active' => request()->routeIs('seed-accessions.*')])>Aksesi benih</a>
        <a href="{{ route('plant-groups.index') }}" @class(['active' => request()->routeIs('plant-groups.*')])>Kelompok tanaman</a>
        <a href="{{ route('treatments.index') }}" @class(['active' => request()->routeIs('treatments.*')])>Perlakuan simpan</a>
    </nav>

    <footer>UTS PPWL Ganjil 2026-2027</footer>
</aside>
