@if (session('success'))
    <x-alert type="success">{{ session('success') }}</x-alert>
@endif
@if (session('error'))
    <x-alert type="error">{{ session('error') }}</x-alert>
@endif
@if ($errors->any())
    <x-alert type="error">
        Data belum bisa disimpan. Periksa isian berikut:
        <ul>
            @foreach ($errors->all() as $message)
                <li>{{ $message }}</li>
            @endforeach
        </ul>
    </x-alert>
@endif
