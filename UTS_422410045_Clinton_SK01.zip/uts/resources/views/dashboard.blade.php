@extends('layouts.app')
@section('title', 'Ringkasan')

@section('content')
    <div class="page-head">
        <div>
            <h1>Ringkasan koleksi</h1>
            <p class="lead">Kondisi terkini aksesi benih varietas lokal yang tersimpan.</p>
        </div>
        <a class="btn" href="{{ route('seed-accessions.create') }}">Tambah aksesi</a>
    </div>

    <div class="stats">
        <div class="stat"><b>{{ $totalAccessions }}</b><span>Aksesi tercatat</span></div>
        <div class="stat"><b>{{ number_format($totalGrams, 0, ',', '.') }} g</b><span>Total berat benih</span></div>
        <div class="stat"><b>{{ $byStatus['karantina'] ?? 0 }}</b><span>Dalam karantina</span></div>
        <div class="stat"><b>{{ $totalTreatments }}</b><span>Jenis perlakuan simpan</span></div>
    </div>

    <div class="two-col">
        <section class="card">
            <h2>Aksesi per kelompok tanaman</h2>
            @php($max = max(1, $groups->max('seed_accessions_count')))
            @foreach ($groups as $group)
                <div style="margin-bottom:.8rem">
                    <div style="display:flex;justify-content:space-between">
                        <span>{{ $group->name }}</span><b>{{ $group->seed_accessions_count }}</b>
                    </div>
                    <div class="bar"><i style="width:{{ $group->seed_accessions_count / $max * 100 }}%"></i></div>
                </div>
            @endforeach
        </section>

        <section class="card">
            <h2>Terakhir ditambahkan</h2>
            @forelse ($latest as $item)
                <div style="display:flex;justify-content:space-between;align-items:center;padding:.55rem 0;border-bottom:1px solid var(--line)">
                    <div>
                        <a href="{{ route('seed-accessions.show', $item) }}">{{ $item->name }}</a><br>
                        <small class="lead">{{ $item->plantGroup->name }}</small>
                    </div>
                    <x-seed-tag :code="$item->code" />
                </div>
            @empty
                <p class="empty">Belum ada aksesi. Mulai dengan menambahkan aksesi pertama.</p>
            @endforelse
        </section>
    </div>
@endsection
