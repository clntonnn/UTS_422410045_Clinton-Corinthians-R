@extends('layouts.app')
@section('title', 'Tambah aksesi')

@section('content')
    <div class="page-head"><h1>Tambah aksesi benih</h1></div>
    <form method="POST" action="{{ route('seed-accessions.store') }}">
        @csrf
        @include('seed-accessions._form')
    </form>
@endsection
