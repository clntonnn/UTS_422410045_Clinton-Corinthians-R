@extends('layouts.app')
@section('title', 'Aksesi benih')

@section('content')
    <div class="page-head">
        <div>
            <h1>Aksesi benih</h1>
            <p class="lead">{{ $accessions->total() }} aksesi ditemukan.</p>
        </div>
        <a class="btn" href="{{ route('seed-accessions.create') }}">Tambah aksesi</a>
    </div>

    <form method="GET" class="card filters">
        <div class="field">
            <label for="q">Cari</label>
            <input id="q" name="q" value="{{ request('q') }}" placeholder="Kode, nama, nama lokal, atau kabupaten asal">
        </div>
        <div class="field">
            <label for="plant_group_id">Kelompok</label>
            <select id="plant_group_id" name="plant_group_id">
                <option value="">Semua</option>
                @foreach ($groups as $g)
                    <option value="{{ $g->id }}" @selected(request('plant_group_id') == $g->id)>{{ $g->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="field">
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="">Semua</option>
                @foreach ($statuses as $s)
                    <option value="{{ $s }}" @selected(request('status') === $s)>{{ ucfirst($s) }}</option>
                @endforeach
            </select>
        </div>
        <div class="field">
            <label for="treatment_id">Perlakuan</label>
            <select id="treatment_id" name="treatment_id">
                <option value="">Semua</option>
                @foreach ($treatments as $t)
                    <option value="{{ $t->id }}" @selected(request('treatment_id') == $t->id)>{{ $t->name }}</option>
                @endforeach
            </select>
        </div>
        <div style="display:flex;gap:.4rem">
            <button class="btn" type="submit">Terapkan</button>
            <a class="btn ghost" href="{{ route('seed-accessions.index') }}">Reset</a>
        </div>
    </form>

    <div class="card flush">
        <div class="table-wrap">
            <table>
                <thead>
                    <tr><th>Kode</th><th>Benih</th><th>Asal</th><th>Perlakuan</th><th>Status</th><th></th></tr>
                </thead>
                <tbody>
                @forelse ($accessions as $item)
                    <tr>
                        <td><x-seed-tag :code="$item->code" /></td>
                        <td>
                            <a href="{{ route('seed-accessions.show', $item) }}"><b>{{ $item->name }}</b></a><br>
                            <small class="lead">{{ $item->plantGroup->name }} &middot; {{ number_format($item->quantity_grams, 0, ',', '.') }} g</small>
                        </td>
                        <td>{{ $item->origin?->regency }}<br><small class="lead">{{ $item->origin?->province }}</small></td>
                        <td>
                            <div class="chips">
                                @forelse ($item->treatments as $t)
                                    <span class="chip">{{ $t->name }}</span>
                                @empty
                                    <small class="lead">Belum ada</small>
                                @endforelse
                            </div>
                        </td>
                        <td><x-status-badge :status="$item->status" /></td>
                        <td class="actions">
                            <a class="btn ghost sm" href="{{ route('seed-accessions.edit', $item) }}">Ubah</a>
                            <x-delete-button :action="route('seed-accessions.destroy', $item)" :confirm="'Hapus aksesi '.$item->code.'?'" />
                        </td>
                    </tr>
                @empty
                    <tr><td colspan="6" class="empty">Tidak ada aksesi yang cocok. Ubah kata kunci atau reset filter.</td></tr>
                @endforelse
                </tbody>
            </table>
        </div>
        @if ($accessions->hasPages())
            <div class="pagination-wrap">{{ $accessions->links() }}</div>
        @endif
    </div>
@endsection
