@extends('layouts.app')
@section('title', 'Ubah aksesi')

@section('content')
    <div class="page-head"><h1>Ubah aksesi {{ $accession->code }}</h1></div>
    <form method="POST" action="{{ route('seed-accessions.update', $accession) }}">
        @csrf
        @method('PUT')
        @include('seed-accessions._form')
    </form>
@endsection
