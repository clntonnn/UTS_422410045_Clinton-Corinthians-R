@extends('layouts.app')
@section('title', $accession->name)

@section('content')
    <div class="page-head">
        <div>
            <x-seed-tag :code="$accession->code" />
            <h1 style="margin-top:.5rem">{{ $accession->name }}</h1>
            @if ($accession->local_name)<p class="lead">Nama lokal: {{ $accession->local_name }}</p>@endif
        </div>
        <div>
            <a class="btn ghost" href="{{ route('seed-accessions.index') }}">Kembali</a>
            <a class="btn" href="{{ route('seed-accessions.edit', $accession) }}">Ubah</a>
            <x-delete-button :action="route('seed-accessions.destroy', $accession)" :confirm="'Hapus aksesi '.$accession->code.'?'" />
        </div>
    </div>

    <div class="two-col">
        <section class="card">
            <h2>Data aksesi</h2>
            <dl class="meta">
                <dt>Kelompok tanaman</dt><dd>{{ $accession->plantGroup->name }}</dd>
                <dt>Jumlah benih</dt><dd>{{ number_format($accession->quantity_grams, 0, ',', '.') }} g</dd>
                <dt>Status</dt><dd><x-status-badge :status="$accession->status" /></dd>
                <dt>Catatan</dt><dd>{{ $accession->notes ?: '-' }}</dd>
            </dl>
        </section>

        <section class="card">
            <h2>Asal pengumpulan</h2>
            @if ($accession->origin)
                <dl class="meta">
                    <dt>Provinsi</dt><dd>{{ $accession->origin->province }}</dd>
                    <dt>Kabupaten/kota</dt><dd>{{ $accession->origin->regency }}</dd>
                    <dt>Desa/kecamatan</dt><dd>{{ $accession->origin->village ?: '-' }}</dd>
                    <dt>Ketinggian</dt><dd>{{ $accession->origin->altitude_masl !== null ? $accession->origin->altitude_masl.' mdpl' : '-' }}</dd>
                    <dt>Pengumpul</dt><dd>{{ $accession->origin->collector_name }}</dd>
                    <dt>Tanggal</dt><dd>{{ $accession->origin->collected_at->translatedFormat('d F Y') }}</dd>
                </dl>
            @else
                <p class="empty">Detail asal belum diisi.</p>
            @endif
        </section>
    </div>

    <section class="card">
        <h2>Perlakuan penyimpanan</h2>
        @forelse ($accession->treatments as $t)
            <div style="padding:.5rem 0;border-bottom:1px solid var(--line)">
                <b>{{ $t->name }}</b> @if($t->temperature)<span class="chip">{{ $t->temperature }}</span>@endif
                <div class="lead">{{ $t->description }}</div>
            </div>
        @empty
            <p class="empty">Belum ada perlakuan. <a href="{{ route('seed-accessions.edit', $accession) }}">Pilih perlakuan</a>.</p>
        @endforelse
    </section>
@endsection
