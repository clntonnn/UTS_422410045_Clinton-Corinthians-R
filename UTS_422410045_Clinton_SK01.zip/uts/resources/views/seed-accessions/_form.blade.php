@php($origin = $accession->origin)
@php($selected = old('treatment_ids', $accession->treatments->pluck('id')->all()))

<section class="card">
    <h2>Data aksesi</h2>
    <div class="grid-2">
        <x-field name="code" label="Kode aksesi" :value="$accession->code" hint="Huruf kapital, angka, tanda hubung. Contoh: BNH-0007" />
        <x-field name="name" label="Nama aksesi" :value="$accession->name" />
        <x-field name="local_name" label="Nama lokal" :value="$accession->local_name" />

        <div @class(['field', 'has-error' => $errors->has('plant_group_id')])>
            <label for="plant_group_id">Kelompok tanaman</label>
            <select id="plant_group_id" name="plant_group_id">
                <option value="">Pilih kelompok</option>
                @foreach ($groups as $g)
                    <option value="{{ $g->id }}" @selected(old('plant_group_id', $accession->plant_group_id) == $g->id)>{{ $g->name }}</option>
                @endforeach
            </select>
            @error('plant_group_id')<div class="error">{{ $message }}</div>@enderror
        </div>

        <x-field name="quantity_grams" type="number" label="Jumlah benih (gram)" :value="$accession->quantity_grams ?? 0" />

        <div @class(['field', 'has-error' => $errors->has('status')])>
            <label for="status">Status</label>
            <select id="status" name="status">
                @foreach ($statuses as $s)
                    <option value="{{ $s }}" @selected(old('status', $accession->status ?? 'aktif') === $s)>{{ ucfirst($s) }}</option>
                @endforeach
            </select>
            @error('status')<div class="error">{{ $message }}</div>@enderror
        </div>

        <x-field class="span-2" name="notes" type="textarea" label="Catatan" :value="$accession->notes" />
    </div>
</section>

<section class="card">
    <h2>Asal pengumpulan</h2>
    <div class="grid-2">
        <x-field name="origin[province]" label="Provinsi" :value="$origin?->province" />
        <x-field name="origin[regency]" label="Kabupaten/kota" :value="$origin?->regency" />
        <x-field name="origin[village]" label="Desa/kecamatan" :value="$origin?->village" />
        <x-field name="origin[altitude_masl]" type="number" label="Ketinggian (mdpl)" :value="$origin?->altitude_masl" />
        <x-field name="origin[collector_name]" label="Nama pengumpul" :value="$origin?->collector_name" />
        <x-field name="origin[collected_at]" type="date" label="Tanggal pengumpulan" :value="$origin?->collected_at?->format('Y-m-d')" />
    </div>
</section>

<section class="card">
    <h2>Perlakuan penyimpanan</h2>
    <p class="lead" style="margin-bottom:.8rem">Pilih satu atau lebih perlakuan yang diterapkan pada aksesi ini.</p>
    <div class="checks">
        @forelse ($treatments as $t)
            <label class="check">
                <input type="checkbox" name="treatment_ids[]" value="{{ $t->id }}" @checked(in_array($t->id, $selected))>
                <span>{{ $t->name }}<small>{{ $t->temperature ?? 'Tanpa suhu khusus' }}</small></span>
            </label>
        @empty
            <p class="empty">Belum ada perlakuan. <a href="{{ route('treatments.create') }}">Tambah perlakuan</a> dulu.</p>
        @endforelse
    </div>
    @error('treatment_ids')<div class="field has-error"><div class="error">{{ $message }}</div></div>@enderror
</section>

<div class="form-actions">
    <button class="btn" type="submit">Simpan aksesi</button>
    <a class="btn ghost" href="{{ route('seed-accessions.index') }}">Batal</a>
</div>
