@extends('layouts.app')
@section('title', 'Perlakuan simpan')

@section('content')
    <div class="page-head">
        <div><h1>Perlakuan penyimpanan</h1><p class="lead">Pilihan perlakuan yang bisa diterapkan pada aksesi.</p></div>
        <a class="btn" href="{{ route('treatments.create') }}">Tambah perlakuan</a>
    </div>
    <div class="card flush">
        <table>
            <thead><tr><th>Nama</th><th>Suhu</th><th>Deskripsi</th><th>Dipakai</th><th></th></tr></thead>
            <tbody>
            @forelse ($treatments as $t)
                <tr>
                    <td><b>{{ $t->name }}</b></td>
                    <td>{{ $t->temperature ?: '-' }}</td>
                    <td>{{ $t->description ?: '-' }}</td>
                    <td>{{ $t->seed_accessions_count }} aksesi</td>
                    <td class="actions">
                        <a class="btn ghost sm" href="{{ route('treatments.edit', $t) }}">Ubah</a>
                        <x-delete-button :action="route('treatments.destroy', $t)" :confirm="'Hapus perlakuan '.$t->name.'?'" />
                    </td>
                </tr>
            @empty
                <tr><td colspan="5" class="empty">Belum ada perlakuan penyimpanan.</td></tr>
            @endforelse
            </tbody>
        </table>
        @if ($treatments->hasPages())<div class="pagination-wrap">{{ $treatments->links() }}</div>@endif
    </div>
@endsection
