@extends('layouts.app')
@section('title', 'Tambah perlakuan')

@section('content')
    <div class="page-head"><h1>Tambah perlakuan penyimpanan</h1></div>
    <form method="POST" action="{{ route('treatments.store') }}">
        @csrf
        @include('treatments._form')
    </form>
@endsection
