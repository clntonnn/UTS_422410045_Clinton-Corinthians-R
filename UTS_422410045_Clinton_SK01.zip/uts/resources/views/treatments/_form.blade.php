<section class="card">
    <div class="grid-2">
        <x-field name="name" label="Nama perlakuan" :value="$treatment->name" />
        <x-field name="temperature" label="Suhu" :value="$treatment->temperature" hint="Contoh: 4 °C" />
        <x-field class="span-2" name="description" type="textarea" label="Deskripsi" :value="$treatment->description" />
    </div>
    <div class="form-actions">
        <button class="btn" type="submit">Simpan perlakuan</button>
        <a class="btn ghost" href="{{ route('treatments.index') }}">Batal</a>
    </div>
</section>
