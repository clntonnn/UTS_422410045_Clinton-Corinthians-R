@extends('layouts.app')
@section('title', 'Ubah perlakuan')

@section('content')
    <div class="page-head"><h1>Ubah perlakuan {{ $treatment->name }}</h1></div>
    <form method="POST" action="{{ route('treatments.update', $treatment) }}">
        @csrf
        @method('PUT')
        @include('treatments._form')
    </form>
@endsection
