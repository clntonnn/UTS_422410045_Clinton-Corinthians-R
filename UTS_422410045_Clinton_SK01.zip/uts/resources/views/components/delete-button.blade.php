@props(['action', 'confirm' => 'Hapus data ini?'])
<form method="POST" action="{{ $action }}" class="inline" onsubmit="return confirm(@js($confirm))">
    @csrf
    @method('DELETE')
    <button type="submit" class="btn danger sm">Hapus</button>
</form>
