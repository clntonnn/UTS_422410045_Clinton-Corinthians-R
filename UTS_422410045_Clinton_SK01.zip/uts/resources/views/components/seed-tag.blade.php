@props(['code'])
<span class="tag">{{ $code }}</span>
