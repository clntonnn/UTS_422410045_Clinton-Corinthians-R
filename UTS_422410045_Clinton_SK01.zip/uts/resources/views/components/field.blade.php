{{-- Komponen input teks/angka/tanggal/textarea dengan pesan error otomatis. --}}
@props(['name', 'label', 'type' => 'text', 'value' => null, 'hint' => null])
@php
    $dot = str_replace(['[', ']'], ['.', ''], $name);
@endphp
<div {{ $attributes->class(['field', 'has-error' => $errors->has($dot)]) }}>
    <label for="{{ $dot }}">{{ $label }}</label>
    @if ($type === 'textarea')
        <textarea id="{{ $dot }}" name="{{ $name }}" rows="3">{{ old($dot, $value) }}</textarea>
    @else
        <input id="{{ $dot }}" type="{{ $type }}" name="{{ $name }}" value="{{ old($dot, $value) }}">
    @endif
    @if ($hint)<div class="hint">{{ $hint }}</div>@endif
    @error($dot)<div class="error">{{ $message }}</div>@enderror
</div>
