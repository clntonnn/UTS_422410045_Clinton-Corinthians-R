@props(['status'])
<span class="badge {{ $status }}">{{ ucfirst($status) }}</span>
