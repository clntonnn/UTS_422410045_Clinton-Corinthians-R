@props(['type' => 'success'])
<div {{ $attributes->class(['alert', $type]) }} role="{{ $type === 'error' ? 'alert' : 'status' }}">{{ $slot }}</div>
