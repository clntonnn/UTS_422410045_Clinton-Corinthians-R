@extends('layouts.app')
@section('title', 'Kelompok tanaman')

@section('content')
    <div class="page-head">
        <div><h1>Kelompok tanaman</h1><p class="lead">Kategori untuk mengelompokkan aksesi benih.</p></div>
        <a class="btn" href="{{ route('plant-groups.create') }}">Tambah kelompok</a>
    </div>
    <div class="card flush">
        <table>
            <thead><tr><th>Nama</th><th>Deskripsi</th><th>Aksesi</th><th></th></tr></thead>
            <tbody>
            @forelse ($groups as $group)
                <tr>
                    <td><b>{{ $group->name }}</b></td>
                    <td>{{ $group->description ?: '-' }}</td>
                    <td>{{ $group->seed_accessions_count }}</td>
                    <td class="actions">
                        <a class="btn ghost sm" href="{{ route('plant-groups.edit', $group) }}">Ubah</a>
                        <x-delete-button :action="route('plant-groups.destroy', $group)" :confirm="'Hapus kelompok '.$group->name.'?'" />
                    </td>
                </tr>
            @empty
                <tr><td colspan="4" class="empty">Belum ada kelompok tanaman.</td></tr>
            @endforelse
            </tbody>
        </table>
        @if ($groups->hasPages())<div class="pagination-wrap">{{ $groups->links() }}</div>@endif
    </div>
@endsection
