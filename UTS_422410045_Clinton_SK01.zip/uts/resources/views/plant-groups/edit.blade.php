@extends('layouts.app')
@section('title', 'Ubah kelompok')

@section('content')
    <div class="page-head"><h1>Ubah kelompok {{ $group->name }}</h1></div>
    <form method="POST" action="{{ route('plant-groups.update', $group) }}">
        @csrf
        @method('PUT')
        @include('plant-groups._form')
    </form>
@endsection
