<section class="card">
    <div class="grid-2">
        <x-field class="span-2" name="name" label="Nama kelompok" :value="$group->name" />
        <x-field class="span-2" name="description" type="textarea" label="Deskripsi" :value="$group->description" />
    </div>
    <div class="form-actions">
        <button class="btn" type="submit">Simpan kelompok</button>
        <a class="btn ghost" href="{{ route('plant-groups.index') }}">Batal</a>
    </div>
</section>
