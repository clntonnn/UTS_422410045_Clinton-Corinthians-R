@extends('layouts.app')
@section('title', 'Tambah kelompok')

@section('content')
    <div class="page-head"><h1>Tambah kelompok tanaman</h1></div>
    <form method="POST" action="{{ route('plant-groups.store') }}">
        @csrf
        @include('plant-groups._form')
    </form>
@endsection
