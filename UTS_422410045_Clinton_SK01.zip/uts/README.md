# Bank Benih Pusaka (SK01) - UTS PPWL Ganjil 2026-2027

Aplikasi administrasi koleksi benih varietas lokal. Laravel 12 + MySQL.

| Kebutuhan studi kasus | Implementasi |
|---|---|
| Data utama (kode, nama aksesi) | `seed_accessions` / `SeedAccession` |
| Kategori (kelompok tanaman) | `plant_groups` / `PlantGroup` (hasMany) |
| Detail (asal pengumpulan, 1:1) | `collection_origins` / `CollectionOrigin` (hasOne) |
| Pilihan jamak (perlakuan simpan) | `treatments` + pivot `accession_treatment` (belongsToMany) |

Fitur: CRUD aksesi/kelompok/perlakuan, pencarian (kode, nama, nama lokal, kabupaten), filter (kelompok, status, perlakuan), validasi Form Request, transaksi di `SeedAccessionService`, Blade layout + partial + component, migration + seeder.

Diagram ada di folder `docs/` (`erd.png`, `class-diagram.png`, plus PDF dan sumber `.dot`).

## Cara menjalankan

1. Buat proyek Laravel 12 baru:
   `composer create-project laravel/laravel UTS_NIM_Nama_SK01`
2. Salin isi folder ini ke dalam proyek tersebut (timpa `routes/web.php` dan `database/seeders/DatabaseSeeder.php` jika diminta).
3. Buat database MySQL `bank_benih`, lalu atur `.env`:
   ```
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=bank_benih
   DB_USERNAME=root
   DB_PASSWORD=
   ```
4. `php artisan migrate --seed`
5. `php artisan serve` lalu buka http://127.0.0.1:8000

Pesan bahasa Indonesia untuk validasi: set `APP_LOCALE=id` dan `APP_FALLBACK_LOCALE=id` di `.env`
(jika paket bahasa belum ada: `php artisan lang:publish`, lalu terjemahkan atau pasang paket lang Indonesia).

## Alur kerja singkat (untuk dijelaskan saat ujian)

`routes/web.php` -> `Route::resource` -> `SeedAccessionController` -> `SeedAccessionRequest` memvalidasi
-> `SeedAccessionService` membuka `DB::transaction` (simpan aksesi, `origin()->create`, `treatments()->sync`)
-> redirect + flash message -> view Blade (`layouts/app` + `partials` + `components`).
Pencarian dan filter berada di scope `search()` dan `filter()` pada model `SeedAccession`.
